/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bubblesortdemo;

/**
 *
 * @author lab_services_student
 */
public class BubbleSortDemo {

    public static void main(String[] args) {
       
        char [] arr = { 'e' , 'a' , 'e' , 'x', 't'};
        
        
        // arr[0] > arr[1] checks if arr[0] appears after arr[1] in the alphabet

// bubble sort in descending order  
 for (int i = 0 ; i < arr.length - 1; i ++) {
        for (int j = 0; j < arr.length - 1 - i; j++) {
            if (arr[j] < arr[j + 1]) {
                // SWAP ARR[J] AND ARR[J+ 1]
                 char temp = arr[j];
                 arr[j] = arr[j+1];
                 arr[j + 1] = temp;
            }
        }
    }
        
     System.out.print("Sorted array (descending):");
        
     for (char c : arr) {
         System.out.print(c + " ");
     }
        
        
        
        
    }
}
