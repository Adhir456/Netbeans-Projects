/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.emaillogin;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class EmailLogin {
    
    private static String savedEmail;
    private static String savedPassword;
    
    public static boolean isValidEmail(String email){
        return email.matches("^[\\w.-]+0[\\w.-]+\\.[a-zA-Z](2,6)$"); //REGEX PATTERN***************************************************
    }
    
    public static boolean isValidPassword(String password){
        return password.length() >= 8 && !password.equals(password.toLowerCase()) &&
                password.matches(".*\\d.*") && !password.matches("[A-Za-z0-9]*");
               
    
    }

    public static void main(String[] args) {
        String email = JOptionPane.showInputDialog("Enter your email");
        String password = JOptionPane.showInputDialog("Enter a password");
        
        if (!isValidEmail(email)){
            JOptionPane.showConfirmDialog(null, "Invalid email.format");
            return;
        }
        
        if (!isValidPassword(password)){
            JOptionPane.showMessageDialog(null,"Password must have 8+ characters,capital letter,number and special character");
            return;
        }
        
        savedEmail = email;
        savedPassword = password;
        JOptionPane.showMessageDialog(null, "Registration Sucessful!");
        
        String loginEmail = JOptionPane.showInputDialog("Enter email to login : ");
        String loginPass = JOptionPane.showInputDialog("Enter Password");
        
        if (loginEmail.equals(savedEmail) && loginPass.equals(savedPassword)){
            JOptionPane.showMessageDialog(null,"Login Sucessful");
            
        } else {
            JOptionPane.showMessageDialog(null,"Login failed.Incorrect email or Password");
        }
        
       
    }
}

//ASSIGNEMNT