/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sortdecending;
import java.util.Arrays;
import java.util.Collections;
/**
 *
 * @author lab_services_student
 */
public class SortDecending {

    public static void main(String[] args) {
        Integer[] numbers = {5,2,8,1,9,10,3,6,4,7};
        
        Arrays.sort(numbers,Collections.reverseOrder()); //sort in descending order
        
        System.out.println("Sorted in Descending");
        
        System.out.println("Sorted in Descending Order:" + Arrays.toString(numbers));
        
        
    }
}
