/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ownmapexample;
import java.util.HashMap;

/**
 *
 * @author lab_services_student
 */
public class OwnMapExample {

    public static void main(String[] args) {
        //Create a dictionary (HaspMap)
        HashMap<String,String> carColors = new HashMap<>();
        
        //Add some items
        carColors.put("Mercedes", "Red");
        carColors.put("Toyota","Blue");
        carColors.put("Bmw","Black");
        
        //Retrieve and print values 
       System.out.println("Color of Mercedes: " + carColors.get("Mercedes"));
       System.out.println("Color of Toyota: " + carColors.get("Toyota"));
       System.out.println("Color of Bmw: " + carColors.get("Bmw"));
        
        
    }
}
