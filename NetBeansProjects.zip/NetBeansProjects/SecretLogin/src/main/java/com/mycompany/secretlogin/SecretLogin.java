/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.secretlogin;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class SecretLogin {

    public static void main(String[] args) {
        final String SECRET = "12345";
        
        String input = JOptionPane.showInputDialog("enter scret access code : ");
        
        if (input.equals(SECRET)) {
        JOptionPane.showMessageDialog(null,"Access granted");
        
    } else {
            JOptionPane.showMessageDialog(null,"Incorrect Code!");
            }
    }
}

//ASSIGNEMNT