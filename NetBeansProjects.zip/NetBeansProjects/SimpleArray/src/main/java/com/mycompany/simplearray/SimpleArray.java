/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplearray;

/**
 *
 * @author lab_services_student
 */
public class SimpleArray {

    public static void main(String[] args) {
       int [] numbers = {10,20,30,40,50};                       //length(indexes) you start counting at 1
                                                                          // int you start counting at 0
       
       for (int i=0; i<numbers.length;i++){ //increment = i+1
           System.out.println("Element at index" +i+":"+numbers[i]);
           
       }
    }
}

