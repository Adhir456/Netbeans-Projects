/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.mycompany.scannerexample;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class ScannerExample {
    

    public static void main(String[] args) {
        
        
        //Create a Scanner object to read input from the user
        
        Scanner scanner = new Scanner (System.in);
        
        //Ask the user for their name 
        System.out.print("Please enter your Name:");
        String Name = scanner.nextLine();
        
        //Ask the user for their Age
        System.out.print("Please enter your Age:");
       int Age = scanner.nextInt();
       
       
       //Display the information
       System.out.println( " Hello "+ Name + " You are: " + Age +  " Years  old ");
        
        
        
        
        
    }
}
