/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraydemo;

/**
 *
 * @author lab_services_student
 */
public class ArrayDemo {

    public static void main(String[] args) {
       //Declare amd initialize
       int[] numbers = {10, 20, 30, 40};
       
       //Access elements
       System.out.println("First element: " + numbers[0]);
       
       //Loop through array
       for (int num : numbers) {
           System.out.println("Value:"   + num);
       }
       
        //Pass to method
        printArray(numbers);
           
    }
    
    public static void printArray(int[] arr) {
        for (int val : arr) {
            System.out.println();
        }
    }
}
