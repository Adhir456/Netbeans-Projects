/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usingscanneroroperator;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class UsingScannerOROperator {

    public static void main(String[] args) {
        //taking the user input by using Scanner
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.print(" Enter your number: ");
        int number = scanner.nextInt();
        //Using OR operator 
        if(number<0 || number>100){
            System.out.println("Number:" +number+ 
                    "Is out of range (0-100)");
        }else{
            System.out.println(" Number: "+number+" is within the range. ");
        }
        
        
        
        
        
        
        
    }
}
