/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pjvariables;

/**
 *
 * @author lab_services_student
 */
public class PjVariables {

    public static void main(String[] args) {
        
        String strID = "";
        String strName = "";
        String strCourse = "";
        
        
        strName = JOptionPane.showinputDialog(null, "Please enter students Name");
        
        
        
        
        
    }
}
