/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.example2;

/**
 *
 * @author lab_services_student
 */
public class Example2 {

    public static void main(String[] args) {
        
        
         for ( int a = 0; a < 5 ; a++ ) {
          
          
          
          System.out.println( a );
      }
        
        
        
        
        
        
        
        
    }
}
