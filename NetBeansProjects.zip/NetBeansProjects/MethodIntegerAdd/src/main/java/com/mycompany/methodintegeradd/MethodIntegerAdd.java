/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodintegeradd;

/**
 *
 * @author lab_services_student
 */
public class MethodIntegerAdd {
    
    // A method that takes two integers and return their sum 
    
    public static int addNumber(int Number1, int Number2){ //parameters int data type 
    return Number1+Number2; // statement  
            
    }

    public static void main(String[] args) {
        
     int num1 = 20;
     int num2 = 45;
     //calling the method and storing the result
     int sum =  addNumber(num1,num2);
     //displaying the result
     
     System.out.println("The sum of the two numbers is:" + sum );
        
      
       
    }
}
