/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.age1;

/**
 *
 * @author lab_services_student
 */
import java.util.Scanner ;

public class Age1 {

    public static void main(String[] args) {
        
      Scanner scanner = new 
              Scanner ( System.in );
      
      System.out.print("Please enter your age");
      
      int age = scanner.nextInt();
      
      if(age>=18){
          
          System.out.println(" You are old enough to get a drivers licence");
      }
      else{ 
          System.out.println("You are not old enough to get a drivers licence");
      }
        
        
        
       scanner.close();
        
        
        
        
    }
}




public class AgeClassification{
    public static void main (String[] args){
        
        Scanner scanner = new
            Scanner( System.in );
        
        System.out.println(" Enter your age ");
        int age = scanner.nextInt();
        
        if ( age < 18 ){
            System.out.println(" You are a minor ");
            
        } else {
            System.out.println( " You are an adult ");
        }
        scanner.close();
    }




}