/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.textfileeditor;
import java.io.*;
import java.util.*;


/**
 *
 * @author lab_services_student
 */
public class TextFileEditor {

    public static void main(String[] args) {
     String filePath = "text";//Your file path here
     String wordToRemove = "deleteMe";
     
     try {
         File inputFile = new File(filePath);
         File tempFile = new File ("temp");
         
         Scanner scanner = new Scanner (inputFile);
        PrintWriter writer = new PrintWriter (new FileWriter(tempFile));
         
         while (scanner.hasNextLine()) {
             String line = scanner.nextLine();
             //Skip lines that contain the wordToRemove
             if (!line.contains(wordToRemove)){
                 writer.println(line);
             }
         }
         
         scanner.close();
         writer.close();
         
         //Replace original file with the updated temp file 
         if (inputFile.delete()) {
             tempFile.renameTo(inputFile);
             System.out.println("Updated file successfully");
         }else {
             System.out.println("Could not delete original file.");
         }
     } catch (IOException e) {
     }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
    }
}
