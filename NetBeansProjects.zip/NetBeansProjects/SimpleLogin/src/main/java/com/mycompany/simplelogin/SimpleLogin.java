/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplelogin;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class SimpleLogin {

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Create a username (max 5 chars,use _) :"); //create a username meeting the specifications
        String password = JOptionPane.showInputDialog("Create a password (min 8 chars) : ") ;
        
        if (!username.contains("_") || username.length() > 5) { //check if username meets specs
        
        JOptionPane.showMessageDialog(null, " Username must include'_' and be 5 characters or less. ");// tells user does not meet specs
        return;
    }
      
        if (password.length() < 8 ) { // length must meet min characters
            JOptionPane.showMessageDialog(null, "Password must be at least 8 characters."); // try again
            return; //
        }
        
        JOptionPane.showMessageDialog(null, "Account created");
        
        String userLogin = JOptionPane.showInputDialog("Enter username to login:"); //same details used 
        String passLogin = JOptionPane.showInputDialog("Enter password:"); //remember the details used 
        
        if (username.equals(userLogin) && password.equals(passLogin) ) {
            JOptionPane.showMessageDialog(null, "Welcome back, " + username + "!"); // welcomes you 
            
        } else{
            JOptionPane.showMessageDialog(null, "Invalid login"); // wrong details used ..................................... 
        }
        
        
    }
}




//ASSIGNEMENT
