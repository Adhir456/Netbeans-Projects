/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movieticketprice;

import javax.swing.JOptionPane;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketPrice {

    public static void main(String[] args) {
        
     Scanner scanner = new Scanner(System.in);
            
     
     System.out.println("Welcome to the Movie Ticket Price Calculator!");
     System.out.println("Please enter your age");
     
     int age = scanner.nextInt();
     double ticketPrice = calculateTicketPrice(age);
     
     if (ticketPrice == 0) {
         System.out.println("Your ticket is Free!");
         
     
     
     }else{ 
         System.out.println("Your ticket price is R" + ticketPrice);
     }
        scanner.close();
        
        
        
    }

    public static double calculateTicketPrice(int age) {
       
        
       if (age < 5){
       
       return 0 ;
       
       } else if (age >= 5)
       else (age <= 12 ){
        
        return 5;
    
    } else if (age>= 13)
    else   (age<= 60){
        
        return 10;
    } else {
            return 7;
            
            
            }
        
        
        
    }
}
