/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentscorearrayjoption;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class StudentScorearrayJOption {

    public static void main(String[] args) {
        int studentCount = Integer.parseInt( // accepting an integer 
        JOptionPane.showInputDialog("Enter number of students : ") //accepting user input - declaration 
        );
        String[] names = new String[studentCount]; // new object which is strings 
        int [] scores = new int [studentCount]; // new object = scores 
        
        //input names and scores
        for(int i = 0; i<studentCount;i++){ // for each loop identify any elements //first index is always 0
            names[i] = JOptionPane.showInputDialog("Enter name of student" + (i+1) + ":"); //increment //allows to enter first name 
            String scoreInput = JOptionPane.showInputDialog("Enter score for " +names[i] + ":") ; 
            scores[i] = Integer.parseInt(scoreInput); //once receieved input you then converting it to an integer 
            
        }
        //Calculate total and average 
        int total = 0; //intialising 0 at the beginning
        int highest = scores[0]; //another integer                
        String topStudent = names[0];                                            
        
        for (int i = 0; i < studentCount;i++){
            total += scores[i];
            if(scores[i]>highest){
                highest = scores[i];
                topStudent = names[i];
            }
        }
        double average = (double)total/studentCount;
        
        //Build the result message
        StringBuilder result = new StringBuilder("Student Score : \n"); //stringbuilder compresses the string from adding a string to another string 
        for (int i = 0 ; i < studentCount; i++){
            result.append(names[i]).append(":").append(scores[i]).append("\n");
        }
        result.append("\nAverage Score : ").append(String.format("%.2f", average)); //float number 
        result.append("\nAverage Score : ").append(highest).append("(").append(topStudent).append(")"); //trying to get highest score 
        
        //show result
        JOptionPane.showMessageDialog(null,result.toString(),"Result",JOptionPane.INFORMATION_MESSAGE);
        
        
        
        
        
    }
}               
