/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arrayprocessor;

/**
 *
 * @author lab_services_student
 */
public class ArrayProcessor {
    
    public static int [] doubleArray (int[] arr){
        int [] result = new int [arr.length];
        for ( int i = 0; i < arr.length; i++)
            result[i] = arr[i] * 2;
        return result;
    }
    
    public static void printArray(int[] arr) {
        for (int num : arr)
            System.out.print(num + " ");
        System.out.println();
    }
 

    public static void main(String[] args) {
       int[] numbers = {2, 4, 6, 8};
       System.out.print("Original: ");
       printArray(numbers);
       System.out.print("Doubled: ");
       printArray (doubleArray(numbers));
    }
}
