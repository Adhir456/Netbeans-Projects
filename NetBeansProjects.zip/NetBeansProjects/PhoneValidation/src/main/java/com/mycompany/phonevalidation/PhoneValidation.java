/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.phonevalidation;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class PhoneValidation {
    
    public static boolean isValidSAphone (String number){
        return number.matches("0\\d{9}");
    }

    public static void main(String[] args) {
        String phone = JOptionPane.showInputDialog("Enter SA phone number eg.(0831234567) :");
        
        if (isValidSAphone(phone)) {
            JOptionPane.showMessageDialog(null, "Valid SA number!" + phone );
        } else {
            JOptionPane.showMessageDialog(null, " Invalid phone number. It must start with '0' and contain 10 digits");
        }
       
    }
}
