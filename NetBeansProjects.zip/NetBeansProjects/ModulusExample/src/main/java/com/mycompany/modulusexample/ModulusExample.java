/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.modulusexample;

/**
 *
 * @author lab_services_student
 */
public class ModulusExample {

    public static void main(String[] args) {
        int Number1 = 40;
        int Number2 = 5;
        
        //using Modulus Operator
        
        int Total = Number1 % Number2 ;
        
        System.out.println("The remainder when " +Number1+ " is Divided by " +Number2+" is " + Total);
    }
}
