/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.totalbillamount;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class TotalBillAmount {
    

    public static void main(String[] args) {
      //Prompt the user for the amount if they are a student 
      String Amount =  JOptionPane.showInputDialog("Enter An Amount ");
      String Check01 = JOptionPane.showInputDialog("If you are a student Enter 1(Yes) or 0(No)");
      // Convert string to double 
      double CheckIfStudent = Integer.parseInt(Check01);
      double AmountDouble = Double.parseDouble(Amount);
      //multiply the amount which has been converted to double with 10%
      double Total = AmountDouble*0.10;
      //deduct the 10% rate from the original amount which is AmountDouble
      double Total01 = AmountDouble-Total;
      
      //Display  the result
      if (CheckIfStudent==1){
          
                  JOptionPane.showMessageDialog(null,"The Total amount after" + "dedection of 10% is :"+Total01+"rands");
                  
      }else{ 
         
      
      JOptionPane.showMessageDialog(null,"You recieved no Discount:"
              + AmountDouble+ " rands ");}
      
      
        
        
        
        
    }
}
