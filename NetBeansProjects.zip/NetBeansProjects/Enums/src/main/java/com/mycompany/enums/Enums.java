/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.enums;

/**
 *
 * @author lab_services_student
 */
public class Enums {
    
    //Enums are kind of like a class
    //They have 'variables'
    //they can have functions/methods
    //the difeerence is enums are used for constant values
    //Enums are used when you know what values will be used,
    //when you know you will be using those values often
    //when you know you wont be needing to change them or add to them
    
    
    enum TrafficLight {
        RED("Red",30,true),
        YELLOW("Yellow",5,false),
        GREEN("Green",25,false);
        
        
        private final String label;
        private final int duration;
        private final boolean stop;
        
        //must be created when you have a enum with subattributes
        TrafficLight(String label, int duration, boolean stop) {
            this.label = label;
            this.duration = duration;
            this.stop = stop;
            
        }
             
        String label () {return label;}
        int duruation() {return duration;}
        boolean isStop() {return stop;}
        
        TrafficLight next() {
            switch (this) {
                case RED: return GREEN;
                case YELLOW: return RED;
                case GREEN: return YELLOW;
            }
            return RED; //unreachable
        }
        
        @Override public String toString(){
            return label + "(" + duration + "s)";
        }
        
        
        
    }
    
    public static void main(String[] args) {
        
        //1.See the data each cnstant carries
        System.out.println("Traffic light data");
        for (TrafficLight t : TrafficLight.values()) {
            System.out.printf(" -@s |  name=@s | stop=@s" , t.toString(),t.label(), t. stop ());
            System.out.print("");
        }
    //create /use  a traffic light enum value 
    TrafficLight chosen = TrafficLight.RED;
    System.out.println("The duration of" + chosen.label() = " is " + chosen.duration());
    
    //compute the sum of a cycle
    int durationSum = 0;
    for (TrafficLight t : TrafficLight.values()) {
        durationSum += t.duration();
    }
    System.out.println("Total duration for a traffic light cyycle is " + durationSum);
    
    //use the next() we create to change the state of the enum
    System.out.println( " Cycle through with next()");
    TrafficLight light = TrafficLight.RED;
    for (int i =0; i < 4; i ++) {
        System.out.println("Current" + light + "| stop" + light.isStop());
        light = light.next();
    }
        
    }
}
