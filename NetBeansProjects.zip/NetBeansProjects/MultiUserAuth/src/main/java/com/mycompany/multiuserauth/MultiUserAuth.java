/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multiuserauth;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class MultiUserAuth {
    
    private static final String[] usernames = new String[2];
    private static final String[] passwords = new String [2];

    public static void main(String[] args) {
      for (int i = 0; i < usernames.length; i++){
          String username = JOptionPane.showInputDialog("Register username for user " + (i + 1) + ":");
          String password = JOptionPane.showInputDialog("Register password for user " + (i + 1) + ":");
          usernames [i] = username;
          passwords [i] = password;
      }
      
      String loginUser = JOptionPane.showInputDialog("Login - Enter Username : ");
      String loginPass = JOptionPane.showInputDialog("Login - Enter Passowrd");
      
      boolean loggedIn = false; //depends on how you want to use boolean 
      for (int i = 0; i < usernames.length; i++){ //increment
          if (usernames[i].equals(loginUser) &&  passwords[i].equals(loginPass)){ //both conditions needs to be true 
              loggedIn = true;                 
              break;
          }
      }
      
      if (loggedIn){
          JOptionPane.showMessageDialog(null, "Login Sucessful!");
          
      } else{
          JOptionPane.showMessageDialog(null, "Login failed ! ");
          
          
      }
    }
}
//ASSIGNEMNT 