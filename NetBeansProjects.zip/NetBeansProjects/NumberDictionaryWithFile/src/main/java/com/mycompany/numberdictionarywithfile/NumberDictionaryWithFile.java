/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberdictionarywithfile;
import java.util.HashMap;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author lab_services_student
 */
public class NumberDictionaryWithFile {

    public static void main(String[] args) {
        //allow user to make input 
        Scanner scanner = new Scanner(System.in);
        // allow for string and retrieval
        HashMap<String, Integer> dictionary = new HashMap<>();
        
        //we capture the number of enteries as a string and convert it
        int count = Integer.parseInt(scanner.nextLine());
        
        //input and update 
        //initialize our i so that we can be able to do increment(i = i + 1)
        for (int i =0; i < count; i++){
        //asking for user to enter name or key
        System.out.print("Enter name/key");
        //we store name/key on the variable
        String key = scanner.nextLine();
        //asking the user to enter a number or value that correspond with entered name 
        System.out.print("Enter number/value'" + key + "':" );
        //recieve the number as a string and than convert it o an integer
        int value = Integer.parseInt(scanner.nextLine());
        //checking out dictionary that we created if it contains key 
        if  (dictionary.containsKey(key)){
            //display the key if it is already stored on the dictionary
            System.out.println("Key already exists! Old value: " + dictionary.get(key));
             //adding a value that will correspond with the name or key 
            System.out.println("Updating to new value:" + value);
        }
        // we stored  key/name and value to our dictiobnary
          dictionary.put(key,value);
        System.out.println("Added/Updated:" + key + " => " + value + "/n" );
            
        }
        //Lookup
        System.out.println("Eneter a name/key to look up");
        String searchkey = scanner.nextLine();
        
        
        if (dictionary.containsKey(searchKey)) {
            System.out.println("Value for'" + searchKey + "':" + dictionary.get(searchKey));
        } else {
            System.out.println("key not found");
        }
        
        //save to file
        try {
            FileWriter writer = new FileWriter("dictionary.txt");
            for ( String key  : dictionary.keySet()) {
                writer.write(key + ":" + dictionary.get(key) + "\n");
            }
        }
        scanner.close();
    }
   }     
