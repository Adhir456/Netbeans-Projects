/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methods;

/**
 *
 * @author lab_services_student
 */
public class Methods {
    
    // This is my method that i have created which will return a fixed string
    public static String getGreeting(){  //before main method 
        
        
        return "Hello,World";
    }

    public static void main(String[] args) {
        
        
        String result = getGreeting();
        
        
        
        //Printing the result 
        System.out.println("The result is:" + result);
        
    
       
       
    }
}
