/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.oopbasics1;
import javax.swing.*;

/**
 *
 * @author lab_services_student
 */



class Dog {
    //Encapsulation
    private String name;
    
    //Construtor
    public Dog(String name) {
        this.name = name;
    }
    
    //method
    public void bark() {
        System.out.println( name + " Says Woof!");
    }
}



public class OOPBasics1 {

    public static void main(String[] args) {
    
        //variable vs constant
        int age = 5;
        final String species = "Dog";
        
        //JOption input
        String name = JOptionPane.showInputDialog(" Enter dog name:");
        
        //Object creation
        Dog myDog = new Dog(name);
        myDog.bark();
        
        //Outdog
        
        JOptionPane.showMessageDialog(null, "Your dog is a" + species + "and is " + age + "years old");
        
        
        
        
        
        
        
    }
}
