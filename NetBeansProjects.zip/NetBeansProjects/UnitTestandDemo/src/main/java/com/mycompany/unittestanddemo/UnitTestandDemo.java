/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.unittestanddemo;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class UnitTestandDemo {

    public static void main(String[] args) {
      System.out.println();
    }
}
