/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.twodimensionalarray;

/**
 * A 2d array is just an array of arrays 
 * @author lab_services_student
 */
public class TwoDimensionalarray {

    public static void main(String[] args) {
       
        
        
        
        //creating an empty array, 
        // you have to create an empty array with dimensions (num of rows and cols)
        int [] [] arr2D = new int [5] [5]; 
        int [] [] arr2D1 = {{1,2,3}, 
            {4,5,6}, 
            {7,8,9}};
        
        //indexing / gatting full row of  A 2d ARRAY 
        int len = arr2D1[0].length;
        System.out.println(len);
        
        //A transversal is how you move through the elements of a 2D array
        //To select a element - > arr {rowNum}{colNum}
        for ( int i = 0; i < arr2D1.length; i ++) {
        
    }
    }
}
