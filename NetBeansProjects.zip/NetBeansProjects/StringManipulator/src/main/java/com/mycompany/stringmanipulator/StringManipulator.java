/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stringmanipulator;

/**
 *
 * @author lab_services_student
 */
public class StringManipulator {

    public static void main(String[] args) {
        
        String s = "Welcome to Java!";
        System.out.println( "Original:" + s);
         System.out.println( "Uppercase:" + s.toUpperCase());
          System.out.println( "Substring(0-7):" + s.substring(0,7));
           System.out.println( "Contains 'Java':" + s.contains("Java"));
            System.out.println( "Replace:" + s.replace("Java" , "Coding"));      
        
    }
}
