/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.joptionexample;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class JOptionExample {

    public static void main(String[] args) {
        //Get User Age
        String ageInput = JOptionPane.showInputDialog("Enter Your Age : ");
        int age = Integer.parseInt(ageInput);
        //Get a membership Status (Yes or No)
        String membershipInput= JOptionPane.showInputDialog("Are you a member(yes or no)");
        boolean isMember = membershipInput.equalsIgnoreCase("yes");
        //using OR(||) - Eligble for discount if age is 60+ or they are a member
        if(age>=60 || isMember){
            JOptionPane.showMessageDialog(null,"Your age is : "+
                    age+"You are eligble for discount");
            //using And (&&)- Extra discount if age 60 + and they are a member
            if(age>=60 && isMember){
                JOptionPane.showMessageDialog(null, "Your age is : " +age+ "You get an extra discount");
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Your age is : " +age+ "Sorry you are not eligble for a discount");
        }
        
        
        
        
        
        
    }
}
