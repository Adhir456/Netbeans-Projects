/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoduserinputstring1;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MethodUserInputString1 {
    
    
    // Method that takes string input from the user
    public static void takeStringInput(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter A string");
        String input = scanner.nextLine();
        System.out.print("Your string which you entered is: " + input);
    
    
    
    }

    public static void main(String[] args) {
        takeStringInput();
    }

    }

