/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.userdictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class UserDictionary {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       
       HashMap<String, String> dictionary = new HashMap<>();
       
       System.out.print("How many words do you want to add?");
       
       int count = Integer.parseInt( scanner.nextLine());
       
       //Input words and meanings
       for (int i = 0; i < count; i++) {
           System.out.print("Enter word:");
           String word = scanner.nextLine().toLowerCase();
           
           System.out.print("Enter meaning of'" +word + "': ");
           String meaning = scanner.nextLine();
           
           dictionary.put(word, meaning);
           System.out.println("Added : " + word + " -> " + meaning + "\n");
               
       }
       
       //Lookup phase 
       System.out.println("Enter a word to look up its meaning:");
       String lookupWord = scanner.nextLine().toLowerCase();
       
       if (dictionary.containsKey(lookupWord)) {
           System.out.println("Meaning of '" + lookupWord + "' : " + dictionary.get(lookupWord));
       } else {
           System.out.println("Word not found in your dictionary.");
       }
       
       scanner.close();
    }
}
