/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraysascending;

import java.util.Arrays;

/**
 *
 * @author lab_services_student
 */
public class ArraysAscending {

    public static void main(String[] args) {
        int[] numbers = {5,2,8,1,9,7,6,10,3};
        
        
        Arrays.sort(numbers); //default sort for ascending
        
        System.out.println("Sorted in Ascending Order" + Arrays.toString(numbers));
    }
}
