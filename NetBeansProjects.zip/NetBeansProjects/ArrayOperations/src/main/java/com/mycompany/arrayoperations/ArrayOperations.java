/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arrayoperations;
import java.util.Arrays;

/**
 *
 * @author lab_services_student
 */
public class ArrayOperations {

    public static void main(String[] args) {
        //1. Declare and initialize arrays
        int [] numbers = {5,3,9,1,4};
        String[] fruits = {"Apple","Banana","Cherry"};
        
        //2. Accessing elements 
        System.out.println("First number : " + numbers[0]);
        System.out.println("Second fruit before change : " + numbers[1]);
        fruits[1] = "Blueberry";
        System.out.println("Second fruit after change : " + fruits[1]);
        
        //3. Loop through Arrays
        System.out.println("\\nAll numbers : ");
        for (int num : numbers){
            System.out.println(num);
            
        }
        
        System.out.println("\nAll fruits : ");
        for (String fruit : fruits){
            System.out.println(fruit);
        }
        
        //4.Sorting the numbers Array
        Arrays.sort(numbers);
        System.out.println("\nSorted numbers : " + Arrays.toString(numbers));
        
        //5. Fill an Array
        int [] empty = new int[5];
        Arrays.fill(empty, 7);
        System.out.println("Filled array:"+Arrays.toString(empty));
        
        
        //6.Copy Array
        int[] copy = Arrays.copyOf(numbers, numbers.length);
        System.out.println("Copied array : " + Arrays.toString(copy));
        
        //7. Binary search
        int index = Arrays.binarySearch(numbers, 4);
        System.out.println("Index of 4 : " + index);
        
        //8. Compare Arrays
        boolean areEqual = Arrays.equals(numbers, copy);
        System.out.println("Are original and copy equal ? " +areEqual);
        
        
                
    }
}
