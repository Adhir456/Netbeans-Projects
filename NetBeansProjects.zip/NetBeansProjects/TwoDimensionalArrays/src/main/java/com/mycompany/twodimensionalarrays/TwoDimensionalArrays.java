/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.twodimensionalarrays;

/**
 *
 * @author lab_services_student
 */
public class TwoDimensionalArrays {

    public static void main(String[] args, String total) {
        //declare  a empty 2 array
        //declare a populated 2D array (Hint: for 1D int int[] 1D = {1,2,3})
        //move / tranverse through the empty array and populate (with same value)
        //create method that prints an array format => [(1, 2, 3, )] first row 
        //                                                ((4, 5,)) second row
        //call print method and pass an array to that method
        
       int[][] emptyArray = new int [2][3];
       
      
       int[][] populatedArray = {
           {1,2,3},
               {4,5,6}
       };
       
       //breadth first traversal 
       //move through the cols of a row before you move down a row 
       
       for (int i = 0; i < emptyArray.length - 1; i++) {
           
        for (int j = 0; j <emptyArray[0].length -1; j++) {
            
            emptyArray[i][j] = 1;
         
            
        }
        
        
       }
        
       printArray(populatedArray);
       System.out.println("------------");
        
       printArray(emptyArray);
       
       // get the totals of each row 
       
       for (int row = 0; row < populatedArray.length; row ++) {
           for (int col = 0; col < populatedArray[0]. length; col ++) {
           }
           System.out.println("\n");
               
       }
       
       for (int col = 0; col < populatedArray.length; col++){
           for (int row = 0; row < populatedArray.length; row ++) {
               total += populatedArray[row] [col];
           }
           System.out.println("total for col" +col+ "is" + total);
       }
          
}  
        
        
        
        
        
        
        
        
        
       
        
        
        
        
        
        
        
    
    public static void printArray ( int[] [] arr) {
        
         for (int j = 0; j < arr.length - 1; j++) {
             int i = 0;
             System.out.print(arr[i][j] + " , ");
         }
             System.out.println("\n");
             
           
       
            
        }
         
        
    }

