/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.joptioninteger;

import javax.swing.JOptionPane;
/**
 *
 * @Adhir 
 */
public class JOptionInteger {

    public static void main(String[] args) {
        //Prompt the user input
        String input1 = JOptionPane.showInputDialog("Enter Your First integer");
        String input2 = JOptionPane.showInputDialog("Enter Your Second integer"); // convert to integer
        
        //Convert input string into integers
        int num1 = Integer.parseInt(input1);
        int num2 = Integer.parseInt(input2); //convert from string to integer 
        
        //Calculate the sum
        int sum = num1 + num2; // add integers 
        
        //diaplaying the result
        JOptionPane.showMessageDialog(null,"The Sum of:" +num1+ " and " +num2+ " Is: "+ sum); // gives results
        
    }
}
