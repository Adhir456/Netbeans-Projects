/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.otpconfirmation;
import javax.swing.JOptionPane;
import java.util.Random;

/**
 *
 * @author lab_services_student
 */
public class OTPConfirmation {

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username");
        String password = JOptionPane.showInputDialog("Enter password");
        
        //Simulate sending OTP
        int otp = new Random().nextInt(9000) + 1000; //4 digit OTP
        JOptionPane.showMessageDialog(null,"Confirmation code sent  to your phone" + otp);
        
        String enteredOTP = JOptionPane.showInputDialog("Enter the confirmation code : ");
        
        if (Integer.toString(otp).equals(enteredOTP)) {
            JOptionPane.showMessageDialog(null,"Registration confirmed.Welcome , " + username + " ! ");
            
        }else {
            JOptionPane.showMessageDialog(null,"Incorrect code. Registration failed" + "Try putting the correct OTP");
        }
    }
}

//ASSIGNEMNT