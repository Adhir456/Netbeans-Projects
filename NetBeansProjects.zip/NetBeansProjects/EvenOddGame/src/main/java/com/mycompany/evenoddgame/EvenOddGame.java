/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.evenoddgame;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class EvenOddGame {
    
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }

    public static void main(String[] args) {
      Scanner scanner = new Scanner (System.in);
      String playAgain;
      
      do {
          System.out.print("Enter a number: ");
          int num = scanner.nextInt();
          scanner.nextLine(); // clear buffer 
          
          if (isEven(num)) {
              System.out.println(num + " is EVEN.");
          } else {
              System.out.println(num + " is ODD");
          }
          System.out.print("Play again? (yes/no) : ");
          playAgain = scanner.nextLine().toLowerCase();
      } while (playAgain.equals("yes"));
      
      System.out.println("Thanks for playing!");
      scanner.close();
    }
}
