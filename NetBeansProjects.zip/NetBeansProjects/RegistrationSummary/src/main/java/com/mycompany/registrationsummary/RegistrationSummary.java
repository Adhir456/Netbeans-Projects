/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationsummary;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class RegistrationSummary {

    public static void main(String[] args) {
        
        String name = JOptionPane.showInputDialog("Enter your name");
        
        
    }
}
