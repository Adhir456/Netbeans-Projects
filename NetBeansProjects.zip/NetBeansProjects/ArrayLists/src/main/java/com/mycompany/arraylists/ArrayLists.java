/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylists;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author lab_services_student
 */
public class ArrayLists {

    public static void main(String[] args) {
 
        // an arraylist is just a list
        // you can think of it as an array
        // the key difference between and arraylist and an array is an arraylist has no fixed
        //to create an empty arraylist import java.util.ArrayList
        
        ArrayList <String> todo = new ArrayList<String>();
      
//        int [] arr = new int [5];
//        
//       // to add an arraylist
//       todo.add("Buy Milk");
//       todo.add("Finish lab");
//       todo.add("Email lecturer");
//       
//       // to display print an array list
//       System.out.println("Todo:" + todo);
//        
//        
//        
//        
//        //when you add to a specific index in array list, 
//        // all elements that are => the index gets pushed to the right 
//        //
//        //syntax to add
//        todo.add( 1, "Have Lunch");
//        System.out.println("Todo:" + todo);
        
//        //to get an element at a specific index
//        String firstItem = todo.get(0);
//        System.out.println("First task:" +firstItem);
//        
//        //to add to a specific index and override
//        todo.add(0," BuyAlmond milk");
//        System.out.println("New List :" +todo);
//        
//        //to search within an arraylist
//        System.out.println("Does list contain \"Finish Lab\"" + todo.contains("Finish lab"));
//        
//        //to search for index of element 
//        System.out.println("Index of \"Email Lecturer\"" +todo.indexOf("Email lecturer"));
//        
//        //to iterate through an array list
//        // the same and an array 
//        
//        for (int i = 0; i < todo.size(); i++) {
//            System.out.println( i + " " + todo.get(i));
//            
//        }
        
//        System.out.println("Enhanced for");
//        for (String task : todo) {
//            System.out.println( task );
//        }
//        
//        System.out.println("Iterator");
//        Iterator<String> it = todo.iterator();
//        while (it.hasNext()) {
//            System.out.println(it.next());
//            
//            
//            
//        }
//        
//        //Bulk poerations (bulk add)
//        //In order to add bulk items they need to be in a list format (Arrays.asList())
//            todo.addAll(Arrays.asList("Clean Desk ", "Sketch"));
//            System.out.println("After ddAll:" + todo);
//        
//            //Remove items that match a condition
//            todo.removeIf(task-> task.toLowerCase().contains("email"));
//            System.out.println("After remove if : " + todo);
//            
//            //sorting an array list 
//            todo.sort(Comparator.naturalOrder());
//            System.out.println("After ordering:" + todo);
//        
//            
//            //conversion arraylist -> Array 
            String [] asArray = todo.toArray(new String[0]);
         System.out.println("Back to Array" + Arrays.toString(asArray));
//            
//            //Arrays -> ArrayList
           List<String> fromArray = new ArrayList<>(Arrays.asList(asArray));
       System.out.println("Back to array list: " + fromArray);   
         
        //arraylist with custom objects
        ArrayList<Student> roster = new Arraylist<>();
        roster.add(new Student("Frodo", 78));
         roster.add(new Student("Sam-wise", 91));
          roster.add(new Student("Merry", 85));
           roster.add(new Student("Pippin", 91));
            roster.add(new Student("Smeagle",60));
            
            System.out.println("Roster(oringinal)" + roster);
        
            
            //Update Sam-Wise to 99
            //1, find where same wise isin the list( methods that returns the index of where sam-wise is)
            //2. update the GRADE of the student at found index  to 99
            //3. method that updates the element at a specific index 
            //you will be creating a new student object to add  
            
            
            
            for (int i = 0; i < roster.size(); i++) {
                if ( roster.get(i).name.contains("Sam") ) {
                    roster.set(i, new Student ("Sam-Wise,", 99));
                    
                }
            }
            
        System.out.println("After updating Sams grade" + roster);
        
    }
}
