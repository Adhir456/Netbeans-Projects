/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.readfile;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class ReadFile {

    public static void main(String[] args) {
        File file = new File ("text.txt"); //file should be in the project folder
       
       try (Scanner fileScanner = new Scanner(file)) {
           System.out.println("Contents of 'text.text':");
           while (fileScanner.hasNextLine()) {
               String line = fileScanner.nextLine();
               System.out.println(line);
           }
       } catch (FileNotFoundException e){
           System.out.println("File not found");
           e.printStackTrace();
       }
    }
}





