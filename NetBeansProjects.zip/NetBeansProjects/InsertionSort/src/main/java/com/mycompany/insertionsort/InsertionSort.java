/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.insertionsort;

/**
 *
 * @author lab_services_student
 */
public class InsertionSort {

    public static void main(String[] args) {
        
        //Think of it like a stack of cards ( list of some object\primitive type) you are given a single card at a time
        // starting from index 0, you want to find the correct  position for your card
        // if the card is < the card (cardcompare) we comparing to shift card compare 1 position to the right
        // do this until you find that the condition you are testing no longer holds (card ! < cardcompare)
        //You can then add card to the position of card compare
        
       int [] arr = {25, 3, 8, 11, 17, 6};
       
       for ( int i = 1; i < arr.length; i ++) {
           
           
           int temp = arr[i];
           int j = i - 1;
            
           while (j >= 0  && arr[j] > temp) {
               
               arr[j+1] = arr[j];
               j--;
               
           }
           
           arr[j+1] = temp;
           
           
           
           
           
           
           
       }
        
        for (int num : arr) {
            
            System.out.println(num + ",");
        }
        
        
        
        
    }
}
