/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.joptioncalculator;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class JOptionCalculator {

    public static void main(String[] args) {
        String num1Str = JOptionPane.showInputDialog("Enter First Number: ");
        double num1 = Double.parseDouble(num1Str);
        
        String operator = JOptionPane.showInputDialog("Enter an operator(+,-,*,/)");
        
        String num2Str = JOptionPane.showInputDialog("Enter Second Number: ");
        double num2 = Double.parseDouble(num2Str);
        
        double result = 0;
        String errorMessage = null;
        switch (operator){
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1-num2;
                break;
                case"*":
                    result = num1*num2;
                    break;
                    case"/":
                        if num2 ! == 0 {
                        result = num1/num2;
                        
                    }else{
                            errorMessage = ("Error: Cannot divide by 0");
                            }
                    break;
                    default:
                        errorMessage("Error: Invalid operator!");
        }
        
        
                        if (errorMessage ! = null){
                        JOptionPane.showMessageDialog(null, errorMessage , "Error" , JOptionPane.ERROR_MESSAGE);
                        
                    } else {
                            JOptionPane.showMessageDialog(null, "Result:" + result , "Result" , JOptionPane.INFORMATION_MESSAGE);
                                   
                            }
        
                        
                        
        
    }
        
      
    }

