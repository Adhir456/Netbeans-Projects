/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmark;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class StudentMark {

    public static void main(String[] args) {
        //Get user Mark for Ice taSK
        String markforicetaskInput = JOptionPane.showInputDialog("Enter Your Ice Task Marks : ");
        int markforicetask = Integer.parseInt(markforicetaskInput);
        
    }
}
