/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multiplestatements;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MultipleStatements {
    
    public static void main(String[] args) {
    
    Scanner scanner = new Scanner( System.in);
    
    
    
    System.out.println(" Value for x:");
        int  x = scanner.nextInt();
    
    System.out.println(" Value for y:");
      int y = scanner.nextInt();

        
        //if-else block with multiple statements
        if(x>y){
            
            //Multiple statements inside the block
            System.out.println("x is greater than y");
            int sum = x+y;
            System.out.println("Sum of x and y:" + sum);
            System.out.println("Difference between x and y :" + (x-y));
        } else {
            //multiple statements inside the else block
           System.out.println(" x is not greater than y");
           int product = x*y;
           System.out.println("Product of x and y: " + product);
           System.out.println("Quotient of x divided by y:" + (x/y));
            
        }
       scanner.close();
        
        
        
        
        
    }
}
