/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author lab_services_student
 */
public class JavaFirstProj {

    public static void main(String[] args) {
        
        String Name = "John";
        
        int Age = 30 ;
        int Number01 = 25 ;
        int Number02 = 35 ;
        
        int Sum = Number01 + Number02 ;
        
        
        
        System.out.println(Name);
        System.out.println(Age);
        
        
        System.out.println(Sum);
    }
}
