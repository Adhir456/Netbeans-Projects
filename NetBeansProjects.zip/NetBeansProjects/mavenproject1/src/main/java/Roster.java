
import com.mycompany.mavenproject1.Student;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class Roster {
    private static Student[] students;
    
    public static void load(Student[] std) {
        students = std;
    }
    public Student[] getStudents() {
        return students;
    }
    
    public static int countPassed() {
        int count = 0;
        for (Student s : students) {
        if (s.getMark() >= 50) {
            count++;
        }
    }
        
        return count;
    }
}
