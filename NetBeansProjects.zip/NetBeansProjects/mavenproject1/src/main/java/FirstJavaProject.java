/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class FirstJavaProject {
    
    public static void main(String[] args){
        
    //here i have declarednmy variable which is of string data type
    
   String Name = "John";
   
   int Age = 30 ;
   int Number01 = 25 ;
   int Number02 = 35 ;
   
   int Sum = Number01 + Number02;
   
   
   System.out.println(Name);
   System.out.println(Age);
   
   System.out.println(Sum);
   
   System.out.println("My name is " + Name + " I am " + Age + " Years old");
    
   
   
   
           } 
    
    
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

