/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import com.mycompany.mavenproject1.Student;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author lab_services_student
 */
public class RosterTest {
    
    private  Student[] baseline;
    
    @BeforeEach
    void SetUp() {
        baseline = new Student[] {new Student("Ava",99),
                                  new Student (" Steve ",45),
                                  new Student (" Mike ",60)};
                      Roster.load(baseline);
        }
    
    public RosterTest() {
        
    }
    
    @Test
    public void testSomeMethod() {
        int expected = 2;
        int actual = Roster.countPassed();
        
        assertEquals(expected, actual);
    }
    
    
}
