/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizzesaccess;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class QuizzesAccess {

    public static void main(String[] args) {
       
        final String accessCode = "QUIZ123";
        
        String name = JOptionPane.showInputDialog("Enter your name: ");
        String code  = JOptionPane.showInputDialog ("Enter access code to start the quiz");
        
        if (code.equals(accessCode)) {
            JOptionPane.showMessageDialog(null,"Access granted,Good luck," + name + "!");
            
        }else {
            JOptionPane.showMessageDialog(null,"Access denied.Incorrect Code.");
        }
    }
}

//ASSIGNMENT