/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class Animal {
     //=================== Base /  Parent / Super class================
        
        /*
        the base class is used to keep track of variables or values and behaviours that are common 
        to all child classes,
        All animals have names and ages, all animals can walk and talk 
        But based on what subclass of animals you have 
        the way they behave eg talk/walk or even the attibutes they have can be different
        can be different so some aniamls have wings 
        
        */
    
    

    
    
            //information hiding -> private class attibutes 
            private String name;
             private int age;
             
            //base constuctor 
            
             /*
             A constuctor is a special method that is created whenever you have a class. the purpose of  a constructor is to 
             set the values on any manditory class attributes. You can define a class constructor explicity (below) but if 
             you do not define one, Jave creates an implicit constructor for you class.
              A constructor is defined by the name of the class and has no return type 
             */
             
             
             public Animal (String name, int age) {
                 /*
                 to refer to the class attributes we use the "this" keyword.
                 this refers to this class. To across the param we just  use their names.
                 */
                 
                 this.name = name;
                 this.age = age;
                 
             }
    
    /*
              we give safe access to class attributes using getters ( returns the value of attributes)
             and setters (sets values of attibutes)
             */
             
             
    public String getName () {
        return this.name;
    }
    
    public int getAge () {
        return this.age;
    }
    
    public void setName() {
        this.name = name;
    };
    
    
      public void setAge() {
        this.age = age;
    };
    
    //behaviour/ methods that will be different in the child classes
      public String speak () {
          return "...";
      }
    public String move() {
        return "walk";
    }
    
    // what cant be overridden in a child class
    public final String kingdom() { return "Anamalia";}
    
    public static String classification () {
        return "some classification";
        
    }
    private void secret () {} //private ->
    //helper method for subclasses 
    public String BasicInfo() {
        return name + "(" + age + ")";
    }
    
    
    
    
}
