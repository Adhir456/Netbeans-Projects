/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inheritance;

/**
 *
 * @author lab_services_student
 */
public class Inheritance {

    
    public static void main (String[] args) {
   
        Animal a1 =  new Dog ("Rex", 2);
        Animal a2 = new Animal ("Skye", 3, true);
         Dog a3 =  new Dog ("Rex", 2, true);
        System.out.println(a2.getName()+ "is an animal ?" + (a1 instanceof Animal));
       
        
            //test overriden methods
            
           System.out.println(a1.getName() + "likes to" + a1.speak());
           System.out.println(a1.getName() + "says" + a1.speak());
            
            System.out.println(a2.getName() + "says" + a2.speak());
            System.out.println(a2.getName() + "says" + a2.speak());
            
            //update using the setters
            a1.setAge(10);
            System.out.println(a3.describe);
            
    }     
        
        
        
      
    }

