/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberdictionary01;
 import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class NumberDictionary01 {

    public static void main(String[] args) {
      //Allows for a reason
      Scanner scanner = new Scanner (System.in);
      
      HashMap< String, Integer> dictionary = new HashMap<>();
      
      
      
      System.out.print("How many enteries do you want to add ? ");
      
      int count = Integer.parseInt(scanner.nextLine());
      
      
      
      
      
      
      
      for  (int i = 0 ; i < count ; i++) {
          System.out.print("Enter name/key");
          String key = scanner.nextLine();
          
          System.out.print("Enter Number/Value for '" + key + ":'" );
          
          
          int value = Integer.parseInt(scanner.nextLine());
          
          dictionary.put(key, value);
          
          System.out.println("Added :" + key + " => " + value + "\n");
          
          
          System.out.print("Enter a name/key to get its number");
          
          String searchKey = scanner.nextLine();
          
          if (dictionary.containsKey(searchKey)){
              
              System.out.println("Value for'" + searchKey + "':" + dictionary.get(searchKey));
          } else {
              
              System.out.println("Key not found in the dictionary . ");
              
              
          }
          
          scanner.close();
      }
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    }
}
