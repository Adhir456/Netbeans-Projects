/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stringdemo;

/**
 *
 * @author lab_services_student
 */
public class StringDemo {

    public static void main(String[] args) {
       String name = " Alice ";
       
       //String Method 
       System.out.println("Length:" + name.length());
        System.out.println("Uppercase:" + name.toUpperCase());
        
        //String to number
        String ageStr = "25";
        int age = Integer.parseInt(ageStr);
         System.out.println("Age + 5 = " + ( age + 5 ));
         
         //StringBuilder
         StringBuilder sb = new StringBuilder(" Hello ");
         sb.append(" World ");
         System.out.println(sb.toString());
                 
    }
}
