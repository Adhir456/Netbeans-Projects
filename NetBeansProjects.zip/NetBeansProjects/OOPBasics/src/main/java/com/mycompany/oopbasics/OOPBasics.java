/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.oopbasics;

/**
 *
 * @author lab_services_student
 */
public class OOPBasics {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
