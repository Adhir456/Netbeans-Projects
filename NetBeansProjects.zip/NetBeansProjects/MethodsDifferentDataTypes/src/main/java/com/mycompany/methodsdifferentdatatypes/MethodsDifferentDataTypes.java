/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodsdifferentdatatypes;

/**
 *
 * @author lab_services_student
 */
public class MethodsDifferentDataTypes {
    //Create a methyod that takes integer datatypes
    public static int IntegerNumbers(int a, int b){
    return a+b;
    
    
}
    
//creating a method thattakes double datatypes
    public static double DoubleNumbers(double Num1,double Num2){
    return Num1 + Num2 ;
    
    }
    //cteating a method with no parameters
    public static String GetFixedString(){
    return "Hello , I am Adhir ";
    }
    
    
    
    
    public static void main(String[] args) {
        //calling the methods
        int x = 20;
        int y = 30;
        double k = 10.5;
        double p = 5.8;
        int sum = IntegerNumbers(x,y);
        double product = DoubleNumbers(k,p);
        String  MyString = GetFixedString();
        
        System.out.println("The sum of the two numbers is : " +sum + "\nThe product of the two numbers is:" + product+ "\n" +MyString);
       
       System.out.println(MyString);
    }

    
      

   
    }

