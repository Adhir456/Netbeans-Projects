/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dowhileexample;

/**
 *
 * @author lab_services_student
 */
public class DoWhileExample {

    public static void main(String[] args) {
        int i = 1;
        do{
            System.out.println("Number:" + i);
            i++;
        }while (i<=5);  //
    }
}
