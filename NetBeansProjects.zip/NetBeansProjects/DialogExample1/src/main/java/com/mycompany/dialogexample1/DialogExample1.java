/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dialogexample1;

import javax.swing.JOptionPane;                            

/**
 *
 * @author lab_services_student
 */
public class DialogExample1 { 

    public static void main(String[] args) {
        
     String name;
     String Surname;
     String StudentNumber;
     name = JOptionPane.showInputDialog(null,"Enter your Name:");
     Surname = JOptionPane.showInputDialog(null,"Enter your Surname:");
     StudentNumber = JOptionPane.showInputDialog(null,"Enter  your Student Number :");
     JOptionPane.showMessageDialog(null,"Name : "+name+" \nSurname: "+Surname+ "\nStudent Number"+StudentNumber);
        
        
    }
}
