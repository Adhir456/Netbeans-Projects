/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.changepassword;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class ChangePassword {
    private static String username = "user1";
    private static String password = "Pass@123";

    public static void main(String[] args) {
      String inputUser = JOptionPane.showInputDialog("Enter username");
        String inputPass = JOptionPane.showInputDialog("Enter password");
        if(inputUser.equals(username)&& inputPass.equals(password)){
            JOptionPane.showMessageDialog(null,"Login successful!");
            String newPass = JOptionPane.showInputDialog("Enter new password:");
            password = newPass;
            JOptionPane.showMessageDialog(null,"Password changed successfully!");
        }else{
            JOptionPane.showMessageDialog(null,"Incorrect username or password.");
        }
    }
}
