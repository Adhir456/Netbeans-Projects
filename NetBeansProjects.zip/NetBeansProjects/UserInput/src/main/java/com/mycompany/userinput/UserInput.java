/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.userinput;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class UserInput {

    public static void main(String[] args) {
           //Create your Scanner object to read input 
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user for input
        System.out.print("Enter yoour Name");
        String Name = scanner.nextLine();
        
        
            //Display the input recieved
          System.out.println(" Hello, " + Name + " How are you doing today");
            
            
            
            
            
            
            
            
            
            
        }
        
        
        
        
        
        
        
    }

