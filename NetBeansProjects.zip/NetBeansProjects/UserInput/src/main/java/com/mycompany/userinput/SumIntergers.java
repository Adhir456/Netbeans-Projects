/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.userinput;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class SumIntergers {
    
    public static void mains(String[] arg) {
    
      Scanner input=new Scanner(System.in);
      int firstNumber=0 , secondNumber=0 ;
      int sum ;
     
      
        
        
        
    System.out.println("Enter First Number");
    firstNumber = input.nextInt();
    System.out.println("Enter Second Number");
    secondNumber = input.nextInt();
    
     sum = firstNumber + secondNumber ;
    
    System.out.println("The sum of the two numbers you entered" + sum);
    
    
       
    
    
    
    
    
        }
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
