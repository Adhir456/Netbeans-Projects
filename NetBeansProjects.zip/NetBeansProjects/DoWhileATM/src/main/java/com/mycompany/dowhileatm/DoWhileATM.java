/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dowhileatm;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class DoWhileATM {

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      int balance = 1000;
      int withdrawal;
      
      do{
          System.out.print("Enter withdrawal amount (or 0 to exit):");
          withdrawal = scanner.nextInt();
          
          
          if (withdrawal>balance){
              System.out.println("Insufficient balance.Try again");
          }else if (withdrawal>0){
              balance -= withdrawal;
              System.out.println("Withdrawal Successful! Remaining"
                      + "balance" +balance);
          }
      }while(withdrawal !=0);
      System.out.println("Thank you for using the ATM");
    }
}
