/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dictionaryapp;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
        
/**
 *
 * @author lab_services_student
 */
public class DictionaryApp {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in); //tells the user welcome
       Map<String,String> dictionary = new HashMap<>(); //allows to store and retrieve
       
       System.out.println("Welcome to the Dictionary App");
       
       
        while (true ) { //takes inside the loop
            System.out.print("\nEnter a word (or type 'exit' to finish): ");
            String word = scanner.nextLine().trim();
            
            if (word.equalsIgnoreCase("exit")) { //types _exit_it breaks
                break;
            }
            
            if (word.isEmpty()) { //if user puts no word  
                System.out.println("Word cannot be empty.");
                continue; // whatever is there it wont show but moves on
                
            }
            
            System.out.print("Enter the definition for \"" + word + "\" :"); // word stored now enter definition
            String definition = scanner.nextLine().trim(); //stores definition 
            
            if (definition.isEmpty()) {
                System.out.println("Definition cannot be empty."); //no definition  shows that no definition
                continue;
            }
            
            dictionary.put(word,definition); // stores word and definition
            System.out.println("Entry added!");
        }
        
        //Print the dictionary
        System.out.println("\n Your Dictionary"); // prints dictionary and gives results
        if (dictionary.isEmpty()) {
            System.out.println("No enteries found");
           
        }   else {
            for (Map.Entry<String,String>entry : dictionary.entrySet()){
                System.out.println(entry.getKey() + ":" + entry.getValue()); // gives result of what was stored 
                
            }
          }
        
    
        scanner.close();
    }
}
