/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javalearningunits;
import javax.swing.*;

/**
 *
 * @author lab_services_student
 */
public class JavaLearningUnits {
    
     //Method (adds two numbers)
    public static int add(int a, int b) {
        return a + b;
    }
    
    //OOP Example 
    static class Animal {
        private String name;
        
        public Animal (String name) {
            this.name = name;
        }
        
        public String speak() {
            return name + " Makes a sound. ";
        }
    }
    
static class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
    
    public String speak() {
        return "Woof! I am " + getClass().getSimpleName();
    }
}
    
    
    
    
    
    public static void main(String[] args) {
        String[] options = {
            "1. OOP Basics",
            "2. Methods",
            "3. Decision Structures",
            "4. Loops",
            "5. Strings",
            "6. Arrays",
            "7. Exit"
        };
        
        int choice;
        do {
            choice = JOptionPane.showOptionDialog(null, "Choose a learning unit:",
                     "Java Learning Units", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
            null,options, options[0]);
            
            switch (choice) {
                case 0 -> {
                Dog dog = new Dog ("Buddy");
                    JOptionPane.showMessageDialog(null,dog.speak(), " OOP Example",JOptionPane.INFORMATION_MESSAGE);
            }
            
            case 1 -> {
            String a = JOptionPane.showInputDialog("Enter first number:");
             String b = JOptionPane.showInputDialog("Enter second number:");
             int result = add(Integer.parseInt(a), Integer.parseInt(b));
             JOptionPane.showMessageDialog(null, "Sum =" + result, "Method Example", JOptionPane.INFORMATION_MESSAGE);
        }
            case 2 -> {
                String input = JOptionPane.showInputDialog("Enter your grade (0-100)");
                int grade = Integer.parseInt(input);
                String result;
                if (grade >=90) result = "A";
                else if (grade >= 80 ) result = "B";
                else result = "Needs Improvement";
                JOptionPane.showMessageDialog(null, "Result:" + result, "Decision Structure", JOptionPane.INFORMATION_MESSAGE);
            }
            case 3 -> {
                StringBuilder output = new StringBuilder();
                for (int i = 1; i <= 5; i++) {
                    output.append("Count: ").append("\n");
                }
                JOptionPane.showMessageDialog(null, output.toString(),"Loop Example",JOptionPane.INFORMATION_MESSAGE);
            }
            case 4 -> {
                String name = JOptionPane.showInputDialog("Enter your name: ");
                String message = "Upper: " + name.toUpperCase() +
                        "\nLength:" + name.length() +
                        "\nFirst 4 chars:" + name.substring(0, Math.min(3, name.length()));
                JOptionPane.showMessageDialog(null,message,"String Example", JOptionPane.INFORMATION_MESSAGE);
            }
            case 5 -> {
                int[] marks = {80, 90, 70, 85};
                int sum = 0;
                for (int mark : marks) sum += mark;
                int avg = sum / marks.length;
                JOptionPane.showMessageDialog(null, "Average:" + avg, "Array Example", JOptionPane.INFORMATION_MESSAGE);
            }
            
            case 6  -> {
                JOptionPane.showMessageDialog(null, "Thank you for learning Java!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            }
            
            default -> {}
            
            }
        }while (choice != 6);
  
    }
}
