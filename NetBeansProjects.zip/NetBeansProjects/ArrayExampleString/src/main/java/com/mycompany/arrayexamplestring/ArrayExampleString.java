/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arrayexamplestring;

/**
 *
 * @author lab_services_student
 */
public class ArrayExampleString {

    public static void main(String[] args) {
       String[] fruits = {"Apple","Banana","Cherry","Orange"};
       fruits[1] = "Mango";//changing "banana" to "mango"
        fruits[2] = "Guava"; //Changing "cherry" to "Guava"
        
        System.out.println("The First element is:" + fruits[0]);
        System.out.println("The second element is:" + fruits[1]);
        System.out.println("The third element is:" + fruits[2]);
        //using the for each loop 
        for (String fruit : fruits){
            System.out.println(fruits);
        }
        


    }
}
