/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.newproject01;

/**
 *
 * @author lab_services_student
 */
public class Newproject01 {

    public static void main(String[] args) {
       
       String Name = "John" ; //Declaration of my String variable with identifier Name
       String Surname = " Smith " ; 
       int Age = 25 ; //Declaration of my interger vaiable with identifier Age
       double Height = 2.8 ; //Declaration of my double varaible with identifier Height
       
       //char CharacterExample = 'B' ;
       if (Age>17) {
           
           System.out.println("You are 18 years and older, you are eligable to drive");
           
       }else{
           
           System.out.println("You are not 18 years or older, you are not eligable to drive");
           
       }
       
       System.out.println(" My name is " +Name+ " My Surname is " 
       +Surname+ " I am " +Age+ " Years old" 
       +" and my height is " +Height+" Meters ");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
