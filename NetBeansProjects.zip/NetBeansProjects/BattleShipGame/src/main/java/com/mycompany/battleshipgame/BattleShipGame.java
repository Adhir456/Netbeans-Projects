/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package battleshipgame;

/**
 *
 * @author lab_services_student
 */
public class BattleShipGame {
    
    public class Ship {
        int row;
        int [] cols =   new int  [3];
        
        public int [] getCol() {
            return cols;
            
            
        }
        public void setCol (int [] colsinput) {
            cols = colsinput;
            
        }
        public int getRow() {
            return row;
        }
        
    }
    public class Board {
        int [][] board = new int [5][5];
        Ship [] ships = new Ship[3];
        
        public  void createBoard () {
            
            
            // outer for loop is used to access every row in the 2D array 
            for (int row = 0; row < board.length - 1; row ++) {
                //inner for loop is used access every col in that row from line above 
                for ( int col = 0; col < board[0].length -1; ) {
                    
                    board[row][col] = 0;
                    
                    
                }
                    
            }
            
            
            
        } 
        
        public void placeBattleShip () {
            //creating battleships 
            for (int i = 0; i < 3; i++) {
               Ship battleship = new Ship();
                //
                int min = 0;
                int max = 4;
                //to get a random integer: (int) ((Math.random() * (max - min + 1) ) + min)
                int row = (int) ((Math.random() * (max - min +1 ) + min)) ;
                battleship.setRow(row);
                int col = (int) ((Math.random() * (max - min +1 ) + min)) ;
                int [] colarr =  {col, col+1, col+2};
                battleship.setCol(colarr);    
                

                     if (board[row][col] != 1) {
if (board[row][col + 1] != 1) {
if (board[row][col + 2] != 1) {

for (int j = 0; j < 3; j++) {
board[row][col+j] = 1; 

}



}
}


}     

                
    
                
                
                }
                    
                    
                  
                    
                }
                
            }
public int[][] getBoard(){
createBoard();
placeBattleship();

returnboard;

            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    public static void main(String[] args) {
        
        
        
        
        
        
    }
}
