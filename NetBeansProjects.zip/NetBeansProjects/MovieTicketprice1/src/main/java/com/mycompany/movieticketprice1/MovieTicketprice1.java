/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movieticketprice1;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketprice1 {

    public static void main(String[] args) {
        
        String Age = JOptionPane.showInputDialog("Enter your age");
        if (Age == null){
        
            return;
        }
        int age = Integer.parseInt(Age);
        double price;
        
        if (age<5){
            price = 0;
            
        } else if (age<= 12){
            price = 5;
        }else if (age<=60){
            price = 10;
        } else{
            price = 7;
        }
        
        JOptionPane.showMessageDialog(null, "Your ticket price is : R" + price);
      
    }
}
