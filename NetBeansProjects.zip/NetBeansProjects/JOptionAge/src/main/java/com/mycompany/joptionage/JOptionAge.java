/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.joptionage;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class JOptionAge {

    public static void main(String[] args) {
        
        String name;
        String number;
        
        
        //get employee details
        name = JOptionPane.showInputDialog(null,"Please enter your name");
        number = JOptionPane.showInputDialog(null,"Please enter your number");
        String input1
        
        
        
        //convert age to an integer
        int age = Integer.parseInt(age);
        
        //check if employee is alllowed for pension
        if (age >= 50);
        
        //display results
        String message = ("Employee Name:" + employeeName + "\n" + "Employee Number:" + employeeNumber + "\n" + "Age:" + age + "\n" + "Pension Allowed:" + (allowed ? "Yes" : "No"));
        
        JOptionPane.showMessageDialog(null,message);
        
        
       
       
       
       
                  
        
    }
}
