/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usingscannerlogicaloperators;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class UsingScannerLogicalOperators {
    

    public static void main(String[] args) {
        //using the scanner to recieve user input
       Scanner scanner = new Scanner(System.in);
       //Captures the data from the user 
       System.out.print("Enter your age : ");
        int age = scanner.nextInt();
        
        //Using the AND operator(&&)
        if(age>=18 && age<=60 ){
        System.out.println("Your Age is : "+age+"You are Eligible to work");
        
    }else{
            System.out.println(" Your Age is : "+age+" Your are not in the working Age Range ");
            }
        
        
    }
}
