/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simplemapexample;
import java.util.HashMap;

/**
 *
 * @author lab_services_student
 */
public class SimpleMapExample {

    public static void main(String[] args) {
        //Create a dictionary (HaspMao)
        HashMap<String,String> fruitColors = new HashMap<>();
        
        // Add some items
        fruitColors.put("Apple","Red");
        fruitColors.put("Banana","Yellow");
        fruitColors.put("Grapes","Green");
        
        //Retrieve and print values
        
       System.out.println("Color of Apple: " + fruitColors.get("Apple"));
       System.out.println("Color of Banana: " + fruitColors.get("Banana"));
       System.out.println("Color of Grapes: " + fruitColors.get("Grapes"));
               
         
        
    }
}
