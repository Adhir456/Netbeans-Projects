/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoduserinputint;
import java.util.Scanner;
/**
 *
 * @author lab_services_student
 */
public class MethodUserInputInt {
    
    //Method that takes integer
    public static void takeIntegerInput(){
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter your integer");
        String input = scanner.nextLine();
       System.out.println("The String you entered is : " + input);
    
    
    
    }

    public static void main(String[] args) {
        takeIntegerInput();
    }
}       
   
    

        
    
        
     
    

 

    
   

