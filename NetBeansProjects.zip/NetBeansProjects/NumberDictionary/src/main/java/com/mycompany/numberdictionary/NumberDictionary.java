/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numberdictionary;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class NumberDictionary {

    public static void main(String[] args) {
      //Allows for a user input
      Scanner scanner = new Scanner(System.in);
      //Allows us to be able to store values and keyys on the dictionary and be able to retrieve it 
      HashMap<String, Integer> dictionary = new HashMap<>();
      
      //Created count so that it can ask the user how many enteries
      //the user would like to make to create a dictionary 
      System.out.print("How many enteries do you want to add?");
      
      
      //we receieve our count (Number of enteries from the user) as a string and convert to integer
        int count = Integer.parseInt (scanner.nextLine());
      
      //input name-number pairs
      //intialising our i = 0 so that we can be able to do increment
      //for i if it is less than our number of enteries we will incement(i=i+1)
      for (int i = 0; i < count; i++) {
          
          //We are asking the user to enter a name or key 
          System.out.print("Enter name /key: ");
          //we are receiving our name or key as a string data type
          String name = scanner.nextLine();
          
          //We are asking the user to enter a Number or a value
          
          System.out.print("Enter number/value for" + name + ":");
          //we recieve the Number or value as a string and than conver it to an integer
          int value = Integer.parseInt(scanner.nextLine());
          //we than create our dictionary and specify how we want our key and value to be stored
          dictionary.put(name, value);
          //display to the user the added key and it correspodence added value
          System.out.println("Added: " + name + "=>" + value + "\n");
      }
      
      
      //Lookup phase
      //We ask the user to enter a Name or key so can we display the correspomding value
      System.out.print("Enter a name/Key to get its number : ");
      //we recieve that Name or key as  a string and store it on a searchKey variable
      String searchKey = scanner.nextLine();
      //if the dictionary that we created previously has the name or key that we are searching for
      if (dictionary.containsKey(searchKey)) {
          //retrieve the value for the searchkey and display it
          System.out.println("Value for'" + searchKey + ":" + dictionary.get(searchKey));
      } else {
          //if the dictionary does not have the search key display key not found
          System.out.println("Key not found in the dictionary.");
      }
      //close the scanner
      scanner.close();
      
      
      
      
      
      
      
      
      
      
      
      
    }
}
