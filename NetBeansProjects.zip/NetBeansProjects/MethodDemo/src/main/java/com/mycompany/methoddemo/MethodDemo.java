/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoddemo;

/**
 *
 * @author lab_services_student
 */
class Calculator {
    //no-parameter method
    public void greet () {
        System.out.println("Welcome to Calculator");
        
    }
    //Parameter method
    public int add(int a, int b) {
        return a + b;
    }
    //constructor
    public Calculator(){
        System.out.println("Calculator created");
    }
}









public class MethodDemo {

    public static void main(String[] args) {
       Calculator calc = new Calculator();
       calc.greet();
       
       System.out.println("Sum: " + calc.add(9,7));
       
       
       
       
       
    }
}
