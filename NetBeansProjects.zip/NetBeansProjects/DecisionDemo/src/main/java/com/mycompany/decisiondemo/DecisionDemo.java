/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.decisiondemo;

/**
 *
 * @author lab_services_student
 */
public class DecisionDemo {

    public static void main(String[] args) {
        int score = 75;
        
        //if-else
        if (score >=50) {
            System.out.println("Pass");
            
        } else {
            System.out.println("Fail");
        }
        
        //nested if
        
        if (score > 70) {
            if (score < 90) {
                System.out.println( " Good Job ");
            }
        }
        
        
        //switch-case
        int day = 2;
        switch (day) {
            case 1-> System.out.println("Monday");
              case 2-> System.out.println("Tuesday");
              default -> System.out.println("Other day");
        }
        
        
        
        
        
        
        
    }
}
