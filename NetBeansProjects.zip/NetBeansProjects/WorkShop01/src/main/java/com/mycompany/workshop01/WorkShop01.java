/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.workshop01;

/**
 *
 * @author lab_services_student
 */
public class WorkShop01 {

    public static void main(String[] args) {
        //using data types
        String Name = "Luke";//Declaring a String Variable
        int Age = 25; // Declaring an integer variable 
        double Height = 1.8;//Double or float variable 
        char letter = 'B';//Declaring a character
        int number01 = 25 ;
                int number02 = 5 ;
                boolean Status = true;//declaring a boolean
                
                //below variables are used on the while loop
                int n = 10;
                int total = 0;
                int i = 1;
       
       
        System.out.println("Hello, " + Name);
        System.out.println("Age is : " + Age);
        System.out.println("Height is : " + Height);
       
        System.out.println("The letter is : "+letter);
        System.out.println("The status is : " + Status);
        //Using string concantination
        System.out.println("My Name is: "+Name+ "\nMy age is: "+Age+ "\nMy height is: "+Height);
        //using  Arithmetic operators
        int sum = number01+number02;//calculating the sum
        int product = number01*number02;//calculating the product
        int difference = number01 - number02;//calculating difference
        int quotient = number01/number02;//calculating division
        
        
        System.out.println("Using the values number01 : " +number01+
                "and number02 "
                        +"\nThe sum is : "+sum+
                "\nThe product is : "+product+
                "\nThe differnce is : "+difference+
                "\nThe quotient is : "+quotient);
        
        //Usingh relational operators together
        //with if else statements
        if(Age>17){
            System.out.println("You are eligible to drive");
           
        }else{
            System.out.println("You are not eligible to drive");
        }
        //using the while loop
        while(i<=n){// loop runs while i is less than or equal to
            total += i ;//add i to the sum
            i++;//Increment
            
            
        }System.out.println("Sum of numbers from 1 to " +n+ " is : " + total);
        
        
        
        
        
        
        
    }
}
