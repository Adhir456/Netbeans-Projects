/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.logicaloperators;

/**
 *
 * @author lab_services_student
 */
public class LogicalOperators {

    public static void main(String[] args) {
        int Age = 200;
       double Height = 1.6;
        boolean hasID = true;
        boolean  HasTheRight = true;
        
        //using the and operator
        if (Age>=18 && hasID){
            System.out.println("You are allowed to drive");
            
        }else{
            System.out.println("You are not allowed to drive");
        }
        //using the OR operator 
        if (Height>=1.8 || HasTheRight){
            System.out.println("you are allowed to participate");
    }else{
            System.out.println("You are not Allowed to participate");
        }
        
    }
}
