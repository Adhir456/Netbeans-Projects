/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifstatements01;

/**
 *
 * @author lab_services_student
 */
public class IfStatements01 {

    public static void main(String[] args) {
        
      int Number01 = 50 ;
      
      int Number02 = 10 ;
      
      int Answer = Number01 + Number02;
      
      System.out.println("The Answer for Number01 + Number02 " + Answer);
      
      if ( Answer >= 40 ){
          
          
          System.out.println("My Answer is greater than or equal to 40");
          
      }else {
          
          System.out.println("Answer is smaller than 40 ");
          
          
        
          
          
          
          
          
          
          
          
          
          
          
          
          
          
      }
      
        
        
        
    }
}
