/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmanager;

/**
 *
 * @author lab_services_student
 */
class Student {
    String name; //this refers to the instance variable, name of the currennt object
   
    int age; //age on the right hand side is the constructor parameter
    double grade; //this.grade - grade
    //sets the instance variable to the value passed to the constructor
    
    public Student(String name,int age,double grade){
        this.name = name;
        this.age = age;
        this.grade = grade; //array on array is a 2 dimensional array*****************************************************************************
    }
    
    public void displayInfo () { //method display info creasted to display the instance variables
        System.out.println("Name : " + name + " | Age: " + age + "| Grade: " + grade);
    }
}

public class StudentManager {

    public static void main(String[] args) {
       Student [] students = {
           new Student ("Alice", 18,88.5),
           new Student("Bob", 19, 74.0),
           new Student ("Charlie", 17, 92.3)
       };
       
       System.out.println("Student Records: ");
       for (Student s : students ) {
           s.displayInfo();
       }
    }
}
