/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loopdemo;

/**
 *
 * @author lab_services_student
 */
public class Loopdemo {

    public static void main(String[] args) {
       // for loop
       for (int i = 1; i <= 5; i ++) {
           System.out.println("For loop i : " + i);
       }
       
       //while loop
       int j = 1;
       while (j <= 5) {
           System.out.println("While loop j: " + j);
           j++;
       }
       
       //nested loop
       for (int row= 1; row <= 3; row++) {
           for (int co1 = 1; co1 <= 2; co1++) {
               System.out.println("[" + row + "," + co1 + " ]");
           }
           System.out.println();
       }
       
    }
}
