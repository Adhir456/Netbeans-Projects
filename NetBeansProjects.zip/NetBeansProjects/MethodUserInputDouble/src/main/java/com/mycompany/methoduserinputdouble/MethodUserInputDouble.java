/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methoduserinputdouble;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class MethodUserInputDouble {
    //method that takes double 
    public static void  takeDoubleInput(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a double number");
        double input  = scanner.nextDouble();
        System.out.println("Double value which you entered is :" + input);
    }

    public static void main(String[] args) {
        takeDoubleInput();
    }
}
