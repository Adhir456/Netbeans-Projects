/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scannerexample02;
 import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class ScannerExample02 {

    public static void main(String[] args) {
        
        Scanner scanner  = new Scanner(System.in) ;
        //Ask the student for the name
        System.out.print("Please Enter your Name:");
        String StudentName = scanner.nextLine();
        //Ask the student for the student number
        System.out.print("Please enter your Student Number:");
        String StudentNumber = scanner.nextLine();
        
        //Ask the user for their grades
        System.out.print("Please enter your grade:");
        double Grade = scanner.nextDouble();
        
        //use Condition constructors to checks if the student passed
        if(Grade>49){
        System.out.println("Hello: " +StudentName+ "  "+ StudentNumber +"You have passed!");
        }else{
            System.out.println(" Hello: " +StudentName+ "  " +StudentNumber +"You have Failed!!!");
        }
        
        
        
        
        
   }
}
