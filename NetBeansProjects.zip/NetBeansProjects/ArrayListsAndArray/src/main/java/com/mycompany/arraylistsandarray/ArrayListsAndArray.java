/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylistsandarray;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author lab_services_student
 */
public class ArrayListsAndArray {

   
        
        static class Student {
            String name;
            int grade;
            
            Student(String name, int grade) {
                this.name = name;
                        this.grade = grade;
                        
            }
            
            @Override
            public String toString() {
                return name + "(" + grade + ")";
            }
        }
        
        public static void demoArrays() {
             // in java "array" is a built in type, classes/types come with methods and class variables
            //java.util.arrays has many useful methods
            //to use array class you need the import java.util.arrays
            //create a 1D array for grades
            int [] score = { 88, 95, 70, 100, 92 };
            
            
            //the array class has a tostring method
            System.out.println("original scores:" + Arrays.toString(score));
             
        }
        
         public static void main(String[] args) {
        
              // in java "array" is a built in type, classes/types come with methods and class variables
            //java.util.arrays has many useful methods
            //to use array class you need the import java.util.arrays
            //create a 1D array for grades
            int [] score = { 88, 95, 70, 100, 92 };
            
            
            //the array class has a tostring method
            
            System.out.println("original scores:" + Arrays.toString(score));
             
            //thge array class has a sort method
            Arrays.sort(score);
            System.out.println("After sort :" + Arrays.toString(score));
            
            //the array class has a sort method 
            //on;y work on a sorted array
            int index = Arrays.binarySearch(score, 95);
             System.out.println("index of 95 is:" + index);
           
             //the array allows you to copy an array into another
             //the copying of one array does not modify the copied
             // int [] scoreDesc = Arrays.sort(score, Collections.reverseOrder());
             //List<int> temp = Arrays.asList(score);
            // int[] top3 Arrays.
             int[] bottom3 = Arrays.copyOf(score, 3);
             int [] subArray = Arrays.copyOfRange(score, 2, 4);
             int [] top3 = Arrays.copyOfRange(score, score.length - 3, score.length);
             System.out.println("Bottom 3 :" + Arrays.toString(bottom3));
             System.out.println("Top 3 :" + Arrays.toString(top3));
             System.out.println(" The subset is: " + Arrays.toString(subArray));
             
                     
          
                    //Fill an array and set everything to ther same value
                    int [] allFourtyFour = new int [5];
                    Arrays.fill(allFourtyFour, 44);
                    System.out.println("44 array : " + Arrays.toString(allFourtyFour));
                    
                    //Arrays class can be sued to print 2D arrays 
                    
                    int [][] grid = {{1,2},{3,4}};
         System.out.println("2D grid :" + Arrays.deepToString(grid));
                    
                    
            
     
     
    
            
            
    }
}
