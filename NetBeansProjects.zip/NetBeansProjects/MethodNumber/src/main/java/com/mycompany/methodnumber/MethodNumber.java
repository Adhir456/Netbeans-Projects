/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodnumber;

/**
 *
 * @author lab_services_student
 */
public class MethodNumber {
    
    //Cresting my method 
    public static int getFixedNumber(){
    return 25 ;
    }

    public static void main(String[] args) {
       
       int result = getFixedNumber() ;
       System.out.print("The Result Is : " + result);
        
        
        
    }
}
