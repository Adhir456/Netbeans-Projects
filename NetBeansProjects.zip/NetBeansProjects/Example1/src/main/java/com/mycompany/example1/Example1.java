/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.example1;

/**
 *
 * @author lab_services_student
 */
public class Example1 {

    public static void main(String[] args) {
        
    
        
     int i = 0 ;
             while ( i < 5 ) {
                 
        
        System.out.println(i++ );
                 
             
             
                
                     
                 
                 
                
             }
                 
                 
             
             }
                
     
             
             }